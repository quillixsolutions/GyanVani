import 'package:chatbot/themeclass.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ThemePage extends StatefulWidget {
  @override
  _ThemePageState createState() => _ThemePageState();
}

class _ThemePageState extends State<ThemePage> {
  double brightness = 1.0; // Default brightness
  String? backgroundImagePath;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    brightness = AppPreferences.getBrightness();
    backgroundImagePath = AppPreferences.getBackgroundImage();
    setState(() {});
  }

  Future<void> _selectBackgroundImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      setState(() {
        backgroundImagePath = image.path;
      });
      await AppPreferences.setBackgroundImage(image.path);
    }
  }


  void _adjustBrightness(double value) {
    setState(() {
      brightness = value;
    });
    AppPreferences.setBrightness(brightness);
  }

  // ... other code ...

  void _saveAndSetWallpaper() async {
    // Save the brightness and background image path to shared preferences
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('brightness', brightness);
    await prefs.setString('backgroundImagePath', backgroundImagePath!);

    // Pop back to chat screen with the updated wallpaper
    Navigator.pop(context);
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Theme Settings"),
      ),
      body: Column(
        children: [
          if (backgroundImagePath != null)
            Expanded(
              child: Opacity(
                opacity: brightness,
                child: Image.file(
                  File(backgroundImagePath!),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          Slider(
            value: brightness,
            min: 0.0,
            max: 1.0,
            onChanged: _adjustBrightness,
          ),
          ElevatedButton(
            onPressed: _selectBackgroundImage,
            child: Text("Select Background Image"),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _saveAndSetWallpaper,
        child: Icon(Icons.done),
      ),
    );
  }
}
