import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:chatbot/themepg.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dash_chat_2/dash_chat_2.dart';
import 'package:easy_dynamic_theme/easy_dynamic_theme.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'aboutUs.dart';
import 'consts.dart';
import 'feedback.dart';
import 'firstPg.dart';
import 'history.dart';
import 'login.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  String? _backgroundImagePath;
  double _brightness = 1.0;
  bool isDarkTheme = false; // To manage theme state

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Method to save a new message to an existing chat document
  Future<void> saveChatMessage(String chatId, Messages message) async {
    final chatDocument = _firestore.collection('chats').doc(chatId);

    // Add the new message to the "messages" array
    await chatDocument.update({
      'messages': FieldValue.arrayUnion([message.toJson()]),
      // Append to the array
      'timestamp': DateTime.now(),
      // Update the timestamp
    });
  }

  User? _user;
  late final FirebaseAuth _auth;
  late final OpenAI _openAI;
  late final ChatUser _currentUser;
  late final ChatUser _gptChatUser;
  late final List<ChatMessage> _messages;
  late final List<ChatUser> _isTyping;
  List<Messages> _messageHistory = [];
  late bool _isSwitched;

  @override
  void initState() {
    super.initState();
    _loadBackground();
    _auth = FirebaseAuth.instance;
    _auth.authStateChanges().listen((user) {
      setState(() {
        _user = user;
      });
    });
    _isSwitched = false;
    _currentUser = ChatUser(id: '1', firstName: 'abc', lastName: 'xyz');
    _gptChatUser = ChatUser(id: '2', firstName: 'Gyan', lastName: 'Vani');
    // _messages = [
    //  // ChatMessage(user:ChatUser(id: '0'),text: 'welcome to geetaGpt Chatbot' , createdAt: DateTime.now()),
    //   ChatMessage(user: ChatUser(id: '1'),text: 'you are a Lord Krishna as per bhagvad gita' , createdAt: DateTime.now()),
    //  // ChatMessage(user: ChatUser(id: '0'),text: 'Type your meassage and press send to start chatting', createdAt: DateTime.now().add(Duration(seconds: 2)))
    // ];
    _messages = [
      ChatMessage(
        user: ChatUser(
          id: 'id',
          firstName: "G",
          lastName: "V",
        ),
        text: 'Get The Knowledge of Bhagwad Geeta',
        createdAt: DateTime.now(),
      ),
    ];
    _isTyping = [];
    _messageHistory = [];
    _openAI = OpenAI.instance.build(
      token: OPENAI_API_KEY,
      baseOption: HttpSetup(receiveTimeout: const Duration(seconds: 3)),
      enableLog: true,
    );
  }

  void _loadBackground() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _backgroundImagePath = prefs.getString('backgroundImagePath');
      _brightness = prefs.getDouble('brightness') ?? 1.0;
    });
  }

  // isDarkTheme = prefs.getBool('isDarkTheme') ?? false;
  // Future<void> _selectBackgroundImage() async {
  //   final ImagePicker picker = ImagePicker();
  //   final XFile? image = await picker.pickImage(source: ImageSource.gallery); // Pick an image from the gallery
  //
  //   if (image != null) {
  //     setState(() {
  //       backgroundImagePath = image.path; // Update the background image path
  //     });
  //
  //     // Save the selected image path to shared preferences
  //     final prefs = await SharedPreferences.getInstance();
  //     await prefs.setString('backgroundImagePath', image.path);
  //   }
  // }

  String getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) {
      return "Good Morning!";
    } else if (hour < 18) {
      return "Good Afternoon!";
    } else {
      return "Good Evening!";
    }
  }

  Future<void> _pickImage(ImageSource imageSource) async {
    ImagePicker picker = ImagePicker();
    Navigator.pop(context);
    XFile? file = await picker.pickImage(source: imageSource);
    if (file != null) {
      _backgroundImagePath = file.path;
      setState(() {});
    }
  }

  void _pickImageDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: Container(
            padding: const EdgeInsets.all(25),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "Select Wallpaper",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    fontFamily: 'opensans',
                  ),
                ),
                const SizedBox(height: 10),
                GestureDetector(
                  onTap: () {
                    _pickImage(ImageSource.gallery);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    color: Colors.transparent,
                    child: const Row(
                      children: [
                        Icon(Icons.image),
                        SizedBox(width: 10),
                        Text(
                          "Select From Gallery",
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w400,
                            fontFamily: 'opensans',
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () async {
                    _pickImage(ImageSource.camera);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    color: Colors.transparent,
                    child: const Row(
                      children: [
                        Icon(Icons.camera_alt),
                        SizedBox(width: 10),
                        Text(
                          "Take Photo",
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w400,
                            fontFamily: 'opensans',
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Padding(
          padding: EdgeInsets.only(left: 87),
          child: Text(
            "Gyan Vani",
            style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 20,
                fontFamily: 'opensans'),
          ),
        ),
      ),
      // resizeToAvoidBottomInset: false,
      body: Container(
        decoration: BoxDecoration(
          image: _backgroundImagePath != null
              ? DecorationImage(
                  image: FileImage(File(_backgroundImagePath!)),
                  fit: BoxFit.cover,
                  // colorFilter: ColorFilter
                )
              : const DecorationImage(
                  image: AssetImage('assets/background_image.jpg'),
                  fit: BoxFit.cover,
                ),
        ),
        child: DashChat(
          typingUsers: _isTyping,
          inputOptions: const InputOptions(
            inputTextStyle:
                TextStyle(color: Colors.black), // Ensures text is black
          ),
          currentUser: _currentUser,
          onSend: (ChatMessage m) async {
            String response = await fetchOpenAIResponse(m);
          },
          messages: _messages,
        ),
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Color.fromRGBO(0, 106, 106, 1.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    getGreeting(),
                    // Display personalized greeting based on the time
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontFamily: 'opensans'),
                  ),
                  if (_user !=
                      null) // Display the current user's email if logged in
                    Text(
                      _user!.email!,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontFamily: 'opensans'),
                    ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.chat_bubble_outline),
              title: const Text('New Chat',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20)),
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          const ChatScreen()), // Avoid creating duplicate chat instances
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text('History',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          const HistoryPage()), // Make sure to point to your history screen
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Theme',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20)),
              trailing: Switch(
                value: isDarkTheme,
                onChanged: _toggleTheme, // Toggle between light and dark themes
              ),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ThemePage(),
                    ));
              },
            ),
            ListTile(
              leading: const Icon(Icons.wallpaper),
              title: const Text('Wallpaper',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20)),
              onTap: _pickImageDialog,
            ),
            ListTile(
              leading: const Icon(Icons.account_box_outlined),
              title: const Text('About Us',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20)),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AboutUs(),
                    ));
              },
            ),
            ListTile(
              leading: const Icon(Icons.feedback),
              title: const Text('Feedback',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20)),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const FeedbackPg(),
                    ));
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Log Out',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20)),
              onTap: () async {
                var sharedPref = await SharedPreferences.getInstance();
                sharedPref.setBool(FirstpgState.KEYLOGIN, false);
                await logOut();
              },
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 18, vertical: 190),
              child: Text('Version : 1.0',
                  style: TextStyle(fontWeight: FontWeight.w300, fontSize: 20)),
            ),
          ],
        ),
      ),
    );
  }

  void _toggleTheme(bool value) {
    setState(() {
      isDarkTheme = value;
      EasyDynamicTheme.of(context)
          .changeTheme(dark: isDarkTheme); // Change theme
    });

    // Save theme preference
    SharedPreferences.getInstance().then((prefs) {
      prefs.setBool('isDarkTheme', isDarkTheme);
    });
  }

  Future<String> fetchOpenAIResponse(ChatMessage m) async {
    // const apiKey = 'sk-proj-Ko7gcNqSVVgLBNZOmk6xT3BlbkFJrO9uJml1Wve9BHzwR6AZ';
    const apiKey = 'sk-proj-roexdQCTRhbOXjSGYqR0T3BlbkFJeKE431smkBM60mGavHzQ';
    // const apiKey = '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';
    const url = 'https://api.openai.com/v1/chat/completions';

    _isTyping.add(_gptChatUser);
    setState(() {
      _messages.insert(0, m); // User's message is added to chat
    });

    try {
      var response = await http.post(
        Uri.parse(url),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $apiKey',
        },
        body: jsonEncode({
          'model': 'gpt-3.5-turbo',
          'messages': [
            {
              "role": "system",
              "content": "you are a Lord Krishna as per Bhagvad gita"
            },
            {"role": "user", "content": m.text},
          ]
        }),
      );

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body); // Decoding JSON response

        // Accessing choices array and processing each element
        for (var element in data['choices']) {
          if (element['message'] != null) {
            setState(() {
              _messages.insert(
                0,
                ChatMessage(
                  user: _gptChatUser,
                  createdAt: DateTime.now(),
                  text: element['message']['content'],
                ),
              );
              _isTyping.remove(_gptChatUser);
            });
            // Optionally, save the chat history to Firestore
          }
        }
        return data['choices'][0]['message']['content'];
      } else {
        log("Hello :---> ${response.body}");
        return 'Failed to get data: ${response.statusCode}';
      }
    } catch (e) {
      return 'Failed to make API call: $e';
    }
  }

  // Future<void> getChatResponse(ChatMessage m) async {
  //   _isTyping.add(_gptChatUser);
  //   setState(() {
  //     _messages.insert(0, m);
  //     _messageHistory = _messages.reversed.map((m) {
  //       if (m.user == _currentUser) {
  //         return Messages(role: Role.user, content: m.text);
  //       } else {
  //         return Messages(role: Role.assistant, content: m.text);
  //       }
  //     }).toList();
  //   });
  //   try {
  //     final request = ChatCompleteText(
  //       model: GptTurbo0301ChatModel(),
  //       messages: _messageHistory,
  //       maxToken: 200,
  //     );
  //     final response = await _openAI.onChatCompletion(request: request);
  //
  //     for (var element in response!.choices) {
  //       if (element.message != null) {
  //         setState(() {
  //           _messages.insert(
  //             0,
  //             ChatMessage(
  //               user: _gptChatUser,
  //               createdAt: DateTime.now(),
  //               text: element.message!.content,
  //             ),
  //           );
  //           _isTyping.remove(_gptChatUser);
  //         });
  //         // Save the updated chat history to Firestore
  //         saveChatHistory(_user!, _messageHistory);
  //       }
  //     }
  //   } catch (error) {
  //     print('Error during chat response: $error');
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(content: Text("Error retrieving chat response")),
  //     );
  //   }
  // }

  // Function to save chat history to Firestore
  Future<void> saveChatHistory(User user, List<Messages> messageHistory) async {
    final chatCollection = FirebaseFirestore.instance.collection('chats');

    final chatDocument = await chatCollection.doc(user.uid).get();

    if (chatDocument.exists) {
      // If the document exists, update the messages and timestamp
      await chatDocument.reference.update({
        'messages': FieldValue.arrayUnion(
            messageHistory.map((m) => m.toJson()).toList()),
        'timestamp': DateTime.now(),
      });
    } else {
      // If the document doesn't exist, create a new one
      await chatCollection.doc(user.uid).set({
        'userId': user.uid,
        'messages': messageHistory.map((m) => m.toJson()).toList(),
        'timestamp': DateTime.now(),
      });
    }
  }

  Future<void> logOut() async {
    await _auth.signOut();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const LogIn()),
    );
  }
}

///TODO:
///
/// 1. Wallpaper
/// 2. chat
/// 3. Default photo(Wallpaper)
