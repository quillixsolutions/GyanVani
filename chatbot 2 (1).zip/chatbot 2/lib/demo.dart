import 'package:flutter/material.dart';
import 'package:dash_chat/dash_chat.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class demopg extends StatefulWidget {
  @override
  _demopgState createState() => _demopgState();
}

class _demopgState extends State<demopg> {
  final ChatUser user = ChatUser(
    name: "Me",
    uid: "12345", // Unique ID for the user
  );

  List<ChatMessage> messages = [];
  final TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dash Chat'),
      ),
      body: Column(
        children: [
          Expanded(
            child: DashChat(
              user: user,
              messages: messages,
              onSend: sendMessage,
            ),
          ),
          SizedBox(height: 16.0),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 8.0),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                hintText: 'Type a message...',
                suffixIcon: IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () {
                    sendMessage(_controller.text as ChatMessage);
                    _controller.clear();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> sendMessage(ChatMessage message) async {
    final url = Uri.parse('https://api.openai.com/v1/chat/completions');
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer sk-proj-dwOw5ndfiAKCvvFwB890T3BlbkFJAcPATB9sf0cnnDM6CFVX',
    };
    final body = json.encode({
      "model": "gpt-3.5-turbo",
      "messages": [
        {"role": "system", "content": "you are a Lord Krishna as per Bhagvad gita"},
        {"role": "user", "content": message.text},
      ]
    });

    final response = await http.post(url, headers: headers, body: body);

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      final messageContent = responseData['choices'][0]['message']['content'];
      setState(() {
        messages.add(
          ChatMessage(
            text: messageContent,
            user: ChatUser(uid: "AI"),
          ),
        );
      });
    } else {
      throw Exception('Failed to send message');
    }
  }
}