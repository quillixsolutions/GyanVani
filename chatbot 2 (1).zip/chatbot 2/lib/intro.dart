import 'package:flutter/material.dart';
import 'package:intro_slider/intro_slider.dart';
import 'details.dart';

class intropg extends StatefulWidget {
  const intropg({Key? key}) : super(key: key);

  @override
  State<intropg> createState() => _intropgState();
}

class _intropgState extends State<intropg> {
  late List<ContentConfig> listContentConfig;

  @override
  void initState() {
    super.initState();

    // Initialize the list; content configurations will be set in `didChangeDependencies`
    listContentConfig = [];
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // Access `MediaQuery` or other inherited widgets here
    listContentConfig = [
      ContentConfig(
        styleTitle: TextStyle(
          fontSize: MediaQuery.of(context).size.height * 0.04,
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontFamily: 'opensans',
        ),
        title: "ज्ञानवाणि में स्वागतम्।",
        description:
        "\n\n\n\n\n\n\n\nउत्तिष्ठत जाग्रत प्राप्य वरान्निबोधत\n\nArise, awake, and stop not until the goal is reached.",
        styleDescription: TextStyle(
          fontSize: MediaQuery.of(context).size.height * 0.03,
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontFamily: 'opensans',
        ),
        backgroundImage: 'assets/img_1.png',
      ),
      ContentConfig(
        styleTitle: TextStyle(
          fontSize: MediaQuery.of(context).size.height * 0.04,
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontFamily: 'opensans',
        ),
        title: "ज्ञानवाणि में आपका स्वागत है",
        description: "\n\n\n\n\n\n\n\nअनुभवेनैव सिद्धिः।\n\nSuccess comes through experience.",
        styleDescription: TextStyle(
          fontSize: MediaQuery.of(context).size.height * 0.03,
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontFamily: 'opensans',
        ),
        backgroundImage: 'assets/img_1.png',
      ),
      ContentConfig(
        styleTitle: TextStyle(
          fontSize: MediaQuery.of(context).size.height * 0.04,
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontFamily: 'opensans',
        ),
        title: "Welcome to Gyan Vani",
        description: "\n\n\n\n\n\n\n\nलोकाः समस्ताः सुखिनो भवन्तु।\n\n May all the people be happy.",
        styleDescription: TextStyle(
          fontSize: MediaQuery.of(context).size.height * 0.03,
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontFamily: 'opensans',
        ),
        backgroundImage: 'assets/img_1.png',
      ),
    ];
  }

  void onDonePress() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => details(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return IntroSlider(
      key: UniqueKey(),
      listContentConfig: listContentConfig,
      onDonePress: onDonePress,
    );
  }
}
