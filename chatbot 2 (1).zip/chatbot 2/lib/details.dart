import 'package:chatbot/login.dart';
import 'package:chatbot/singup.dart';
import 'package:flutter/material.dart';

class details extends StatefulWidget {
  const details({Key? key}) : super(key: key);

  @override
  State<details> createState() => _detailsState();
}

class _detailsState extends State<details> {
  Color blueLagoon = const Color.fromRGBO(0, 106, 106, 1.0);

  TextEditingController fName = TextEditingController();
  TextEditingController lName = TextEditingController();
  TextEditingController mNumber = TextEditingController();


  final _formKey = GlobalKey<FormState>();
  var isLoading = false;

  void _submit() {
    final isValid = _formKey.currentState?.validate();
    if (!isValid!) {
      return;
    }
    _formKey.currentState?.save();
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => SignUp(),));
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Center(child:Image(image: AssetImage("assets/img_4.png"),height: 300,)),
            Form(
              key: _formKey,
              child: Container(
                margin: EdgeInsets.all(20),
                width: screenWidth * 0.8, // Adjust the percentage as needed
                child: Column(
                  children: [
                    Text("Personal Details",style: TextStyle(fontSize: 35,fontWeight: FontWeight.w700, fontFamily: 'opensans'),),
                    SizedBox(height: 20,),
                    TextFormField(
                      controller: fName,
                      decoration: InputDecoration(
                        hintText: "First Name",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10)
                        ),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Enter your First Name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 20,),
                    TextFormField(
                      controller: lName,
                      decoration: InputDecoration(
                        hintText: "Last Name",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10)
                        ),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Enter your First Name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 20,),
                    TextFormField(
                      controller: mNumber,
                      decoration: InputDecoration(
                        hintText: "Mobile Number",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10)
                        ),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter mobile number';
                        }
                        // Validate mobile number using regex
                        // Adjust the regex pattern according to your needs
                        if (!RegExp(r'^[0-9]{10}$').hasMatch(value)) {
                          return 'Please enter a valid mobile number';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: () {
                        _submit();
                      },
                      child: Container(
                        height: 60,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            color: blueLagoon,
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child:
                        const Center(child: Text("Continue",style: TextStyle(color: Colors.white, fontSize: 20,fontWeight: FontWeight.w500, fontFamily: 'opensans'),)),
                      ),
                    ),
                    SizedBox(height:8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text("Don't have an account?", style: TextStyle(fontSize: 15)),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const LogIn()),
                            );
                          },
                          child: const Text("Log In", style: TextStyle(fontSize: 15, color: Colors.cyan)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
