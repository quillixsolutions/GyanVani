import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart'; // For date formatting
import 'package:cached_network_image/cached_network_image.dart'; // For data caching

class HistoryPage extends StatefulWidget {
  const HistoryPage({Key? key}) : super(key: key);

  @override
  _HistoryPageState createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  bool _isLoading = true;
  List<Map<String, dynamic>> _chatHistory = [];
  DocumentSnapshot? _lastDocument; // For pagination
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final int pageSize = 10; // Pagination size

  @override
  void initState() {
    super.initState();
    _fetchChatHistory(); // Fetch initial data
  }

  Future<void> _fetchChatHistory() async {
    final user = _auth.currentUser;

    if (user != null) {
      try {
        Query query = FirebaseFirestore.instance
            .collection('chats')
            .where('userId', isEqualTo: user.uid) // Filter by user ID
            .orderBy('timestamp', descending: true); // Order by timestamp

        if (_lastDocument != null) {
          query = query.startAfterDocument(_lastDocument!); // Pagination
        }

        QuerySnapshot snapshot = await query.get();

        _lastDocument = snapshot.docs.isNotEmpty ? snapshot.docs.last : null; // Update last document

        setState(() {
          _chatHistory = snapshot.docs
              .map((doc) => doc.data() as Map<String, dynamic>)
              .toList(); // Store chat history
          _isLoading = false; // Stop loading indicator
        });

      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Error fetching chat history: ${e.toString()}"),
            backgroundColor: Colors.red,
          ),
        );
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width; // For flexible UI

    return Scaffold(
      appBar: AppBar(
        title: const Text("Chat History"),
      ),
      body: _isLoading // Show loading indicator
          ? const Center(
        child: CircularProgressIndicator(), // Loading indicator
      )
          : ListView.builder(
        itemCount: _chatHistory.length,
        itemBuilder: (context, index) {
          var data = _chatHistory[index];
          var formattedDate = DateFormat('yyyy-MM-dd HH:mm:ss')
              .format((data['timestamp'] as Timestamp).toDate());

          return ListTile(
            title: Text(
              data['content'] ?? "No Content",
              style: const TextStyle(fontSize: 16),
            ),
            subtitle: Text(
              "Sent by: ${data['userId']}\nAt: $formattedDate",
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
            isThreeLine: true, // Allows multi-line layout
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchChatHistory, // Pagination fetch
        child: const Icon(Icons.refresh), // Refresh button
      ),
    );
  }
}
