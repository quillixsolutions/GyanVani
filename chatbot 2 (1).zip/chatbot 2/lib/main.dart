import 'package:easy_dynamic_theme/easy_dynamic_theme.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';
import 'firstPg.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await AppPreferences.init();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(
    EasyDynamicThemeWidget(
      child: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final String title = 'EDT - Example';

  var lightThemeData = new ThemeData(
      primaryColor: Colors.black,
      textTheme: new TextTheme(button: TextStyle(color: Colors.white70)),
      brightness: Brightness.light,
      hintColor: Colors.black);

  var darkThemeData = ThemeData(
      primaryColor: Colors.white,
      textTheme: new TextTheme(: TextStyle(color: Colors.black54)),
      brightness: Brightness.dark,
      hintColor: Colors.white);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: lightThemeData,
      darkTheme: darkThemeData,
      themeMode: EasyDynamicTheme.of(context).themeMode,
      home: Firstpg(),
    );
  }
}
