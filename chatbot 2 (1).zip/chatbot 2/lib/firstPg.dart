import 'dart:async';
import 'package:chatbot/chatScreen.dart';
import 'package:chatbot/login.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'intro.dart';

class Firstpg extends StatefulWidget {
  const Firstpg({Key? key}) : super(key: key);

  @override
  State<Firstpg> createState() => FirstpgState();
}

class FirstpgState extends State<Firstpg> {
  static const String KEYLOGIN = "login";

  void initState() {
    super.initState();
    WhereToGo();
  }

  WhereToGo() async {

    var sharedPref =  await SharedPreferences.getInstance();
    var isLoggedIn =  sharedPref.getBool(KEYLOGIN);

    Timer(
        Duration(seconds: 5),
            () {
          if(isLoggedIn!=null){
            if(isLoggedIn){
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => ChatScreen()));
            }else{
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => LogIn()));
            }
          }else{
            Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (context) => intropg()));
          }
        });
  }
  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;

    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Flexible(
            flex: 2, // Adjusts according to screen size
            child: Center(
              child: Image.asset(
                "assets/img_4.png", // Splash screen image
                height: screenSize.height * 0.5, // Adjusted height
              ),
            ),
          ),
        ],
      ),
    );
  }
}
