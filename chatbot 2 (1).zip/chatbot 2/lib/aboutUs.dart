import 'package:flutter/material.dart';

class AboutUs extends StatefulWidget {
  const AboutUs({Key? key}) : super(key: key);

  @override
  State<AboutUs> createState() => _AboutUsState();
}

class _AboutUsState extends State<AboutUs> {
  final Color blueLagoon = const Color.fromRGBO(0, 106, 106, 1.0);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Scaffold(
        appBar: AppBar(
          title: Center(child: Text("About Us")),
        ),
        body: Column(
          children: [
            SizedBox(height: 20),
            Center(
              child: CircleAvatar(
                backgroundImage: AssetImage("assets/img_6.png"),
                backgroundColor: blueLagoon,
                radius: 70,
              ),
            ),
            Container(
              margin: EdgeInsets.all(10),
              child: Column(
                children: [
                  SizedBox(
                    height: 5,
                  ),
                  Card(
                    child: ListTile(
                      title: Text("About Me"),
                      subtitle: Text(
                          "As the creator of this AI application, I am a dedicated and passionate computer science student with a keen interest in artificial intelligence and its applications. With a strong foundation in programming languages and machine learning techniques, I strive to innovate and create solutions that push the boundaries of technology. Through this project, I aim to showcase my expertise and commitment to leveraging AI for meaningful impact in various domains. I am excited to contribute to the advancement of this rapidly evolving field and am eager to continue exploring its endless possibilities."),
                      leading: Icon(Icons.school_outlined),
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Card(
                    child: ListTile(
                      title: Text("Name"),
                      subtitle: Text("Parth Vimalbhai Nakrani"),
                      leading: Icon(Icons.person_outline_sharp),
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Card(
                    child: ListTile(
                      title: Text("Email"),
                      subtitle: Text("ParthNakrani@gmail.com"),
                      leading: Icon(Icons.person_outline_sharp),
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Card(
                    child: ListTile(
                      title: Text("Group No"),
                      subtitle: Text("3400"),
                      leading: Icon(Icons.numbers),
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Card(
                    child: ListTile(
                      title: Text("University "),
                      subtitle: Text(
                          "ISMA ( Informācijas sistēmu menedžmenta augstskola)"),
                      leading: Icon(Icons.account_balance_outlined),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
