import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class forgotPg extends StatefulWidget {
  const forgotPg({Key? key}) : super(key: key);

  @override
  State<forgotPg> createState() => _forgotPgState();
}

class _forgotPgState extends State<forgotPg> {
  final Color blueLagoon = const Color.fromRGBO(0, 106, 106, 1.0);
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final email = TextEditingController();

  void _submit() {
    final isValid = _formKey.currentState?.validate();
    if (!isValid!) {
      return;
    }
    _formKey.currentState?.save();
  }

  @override
  void dispose(){
    email.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Forgot Password"),
      ),
      body: Form(
        key: _formKey,
        child:  Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Recevie an email to \nreset your password",style: TextStyle(fontSize: 20,fontFamily: 'opensans'),textAlign: TextAlign.center),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.all(20),
              child: TextFormField(
                controller: email,
                decoration: InputDecoration(
                  hintText: "Email Address",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  suffixIcon: const Icon(Icons.email_outlined),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email address';
                  }
                  if (!RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                      .hasMatch(value)) {
                    return 'Invalid email format!';
                  }
                  return null;
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: InkWell(
                onTap: () {
                  resetPassword();
                }, // Trigger the form submission
                child: Container(
                  height: 60,
                  decoration: BoxDecoration(
                    color: blueLagoon,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(
                      "Reset Password",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  Future resetPassword() async{
    try{
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim());
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Password Reset Email Sent")));
      Navigator.pop(context);
    } on FirebaseAuthException catch (e){
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Email are not valid")));
          Navigator.of(context).pop;
    }
  }
}
