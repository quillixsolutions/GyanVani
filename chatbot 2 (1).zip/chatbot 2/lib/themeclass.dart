import 'package:shared_preferences/shared_preferences.dart';

class AppPreferences {
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static Future<void> setBackgroundImage(String path) async {
    await _prefs.setString('backgroundImagePath', path);
  }

  static String? getBackgroundImage() {
    return _prefs.getString('backgroundImagePath');
  }

  static Future<void> setBrightness(double brightness) async {
    await _prefs.setDouble('brightness', brightness);
  }

  static double getBrightness() {
    return _prefs.getDouble('brightness') ?? 1.0;
  }
}
