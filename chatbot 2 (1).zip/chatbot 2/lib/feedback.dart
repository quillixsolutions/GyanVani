import 'package:chatbot/chatScreen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class FeedbackPg extends StatefulWidget {
  const FeedbackPg({Key? key}) : super(key: key);

  @override
  State<FeedbackPg> createState() => _FeedbackPgState();
}

class _FeedbackPgState extends State<FeedbackPg> {
  User? _user;
  late final FirebaseAuth _auth;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _auth = FirebaseAuth.instance;
    _auth.authStateChanges().listen((user) {
      setState(() {
        _user = user;
      });
    });
  }
  bool isChecked = false;
  final dataBaseref = FirebaseDatabase.instance.ref("post");
  TextEditingController first = TextEditingController();
  TextEditingController second = TextEditingController();
  final Color blueLagoon = const Color.fromRGBO(0, 106, 106, 1.0);
  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text("Feedback")),
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.all(15),
          child:  Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 10,),
              Text("What do you think of GyanVani",style: TextStyle(
                fontSize: 15, // Scalable text size
                fontWeight: FontWeight.w700,
                fontFamily: 'opensans',
              ),),
              SizedBox(height: 10,),
              TextField(
                controller: first,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10))
                  ),
                ),
              ),
              SizedBox(height: 10,),
              Text("What are your thoughts about GyanVani?",style: TextStyle(
                fontSize: 15, // Scalable text size
                fontWeight: FontWeight.w700,
                fontFamily: 'opensans',
              ),),
              SizedBox(height: 10,),
              TextField(
                controller: second,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10))
                  ),
                ),
              ),
              SizedBox(height: 10,),
              Row(
                children: [
                  Checkbox(value: isChecked, onChanged: (bool? value) {
                    setState(() {
                      isChecked = value!;
                    });
                  },),
                  Text("I'm using GyanVani",style: TextStyle(
                    fontSize: 15, // Scalable text size
                    fontWeight: FontWeight.w700,
                    fontFamily: 'opensans',
                  ),)
                ],
              ),
              SizedBox(height: 20,),
              InkWell(
                onTap: () {
                  dataBaseref.push().set({
                    "email": _user!.email!.toString(),
                    "feedback" : first.text.toString(),
                    "review": second.text.toString(),
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                       SnackBar(content: Text("Thank you for Feedback")));
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ChatScreen(),));
                },
                child: Container(
                  height: 60,
                  decoration: BoxDecoration(
                    color: blueLagoon,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(
                      "Submit Feedback",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: screenSize.height * 0.03,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
